#
# Find optimal hyperparameters using 5-fold validation of the training dataset
#

from convert_dataset import*
from models import*
import numpy



#reduce the dataset, keeping only examples with class in 'keep'
def redux(X,Y,keep = [0,2,3,6,8]):

    
    a_map = dict(zip(keep,range(len(keep))))

    data = []
    for i in zip(X,Y):
        if numpy.argmax(i[1]) in keep:
            y = numpy.zeros(len(keep))
            y[a_map[numpy.argmax(i[1])]] = 1
            data.append((i[0],y))
    return map(numpy.array, zip(*data))

if __name__ == "__main__":
    #model = LinearRegression()
    model = NaiveBayes()
    do_redux = False
    
    #find best threshold
    for threshold in range(32,16):
        sets = extract_features_kfold("dataset_oneclass_train","dataset_oneclass_test", 5, 
                                      threshold, mostn=-1)
        lr_scores = []
        for trainX,trainY,validX,validY,testX,testY in sets:
            if do_redux:
                trainX,trainY = redux(trainX,trainY)
                testX,testY = redux(testX,testY)
                validX,validY = redux(validX,validY)
            print trainX.shape
            model.fit([trainX,trainY])
            train_score = model.test([trainX,trainY])[1]
            test_score = model.test([testX,testY])[1]
            valid_score = model.test([validX,validY])[1]
            lr_scores.append([train_score, test_score, valid_score])
        lr_scores = numpy.array(lr_scores)
        print threshold,numpy.mean(lr_scores,axis=0)[0], numpy.var(lr_scores,axis=0)[0],
        print numpy.mean(lr_scores,axis=0)[2], numpy.var(lr_scores,axis=0)[2]
        
    print 
    # find best mostn
    for n in range(10,130,10):
        sets = extract_features_kfold("dataset_oneclass_train","dataset_oneclass_test", 5, 11, mostn=n)
        lr_scores = []
        for trainX,trainY,validX,validY,testX,testY in sets:
            if do_redux:
                trainX,trainY = redux(trainX,trainY)
                testX,testY = redux(testX,testY)
                validX,validY = redux(validX,validY)
            model.fit([trainX,trainY])
            train_score = model.test([trainX,trainY])[1]
            test_score = model.test([testX,testY])[1]
            valid_score = model.test([validX,validY])[1]
            lr_scores.append([train_score, test_score, valid_score])
        lr_scores = numpy.array(lr_scores)
        print n,numpy.mean(lr_scores,axis=0)[0], numpy.var(lr_scores,axis=0)[0],
        print numpy.mean(lr_scores,axis=0)[2], numpy.var(lr_scores,axis=0)[2]
        

