# -*- encoding: utf-8 -*-
# go through each tweet
# for each label we want a count/average for # of character

'''
DICTIONARY INDEX
0 -> !
1 -> ?
2 -> . (individual)
3 -> . (more than 1 together)
4 -> , 
5 -> caps
6 -> # characters in tweet
7 -> # words in tweet

LABELS
(A)nger/rage",
(C)ontempt/disgust",
(D)istress/anguish",
(E)njoyment/joy",
(F)ear/terror",
(H)umiliation/shame",
(I)nterest/excitement",
(S)urprise",
(N)eutral"
'''

import re
from view import *

def label_to_index(label):
	label = label.upper()
	if label=='A':
		return 0
	elif label=='C':
		return 1
	elif label=='D':
		return 2
	elif label=='E':
		return 3
	elif label=='F':
		return 4
	elif label=='H':
		return 5
	elif label=='I':
		return 6
	elif label=='S':
		return 7
	else:
		return 8

# file_name refers to a training set!!! (we will use this to build features)
def get_counts(file_name, count_threshold=5):
        if type(file_name) == str:
                # open the file
                f = open(file_name, 'r')
                # create dictionary 
        else:
                # then file_name is an iterable object
                f = file_name
	char_dictionary = {0:[0.]*9, 1:[0.]*9, 2:[0.]*9, 3:[0.]*9, 4:[0.]*9, 5:[0.]*9, 6:[0.]*9, 7:[0.]*9}
	word_dictionary = {}

	for line in f:
		# somehow extract the words and labels
		identity, label, tweet = line.split(' ',2)
		tweet = eval(tweet)
		label = label_to_index(label)
		# get number of !
		char_dictionary[0][label] += tweet.count('!')
		# get number of ?
		char_dictionary[1][label] += tweet.count('?')
		# get number of single periods
		char_dictionary[2][label] += len(re.findall("(([^\.]|^)\.([^\.]|$))", tweet))
		# get number of more than one period together
		char_dictionary[3][label] += len(re.findall(u"(([\.]{2,}|…))", tweet))
		# get number of commas
		char_dictionary[4][label] += tweet.count(',')
		# get number of caps
		char_dictionary[5][label] += sum(1 for letter in tweet if letter.isupper())
		# get number of characters
		char_dictionary[6][label] += len(tweet)
		# get number of words
		char_dictionary[7][label] += len(tweet.split(' '))
		

		tweet = re.sub("((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)", "", tweet)
		# build words and labels
		for word in re.split('[^a-zA-Z0-9\']+', tweet.lower()):
                        if len(word) <= 0: continue
			if not word in word_dictionary:
				word_dictionary[word] = [0.]*9
			word_dictionary[word][label]+=1

	# divide char_dict[:][i] by # tweets with label i
	# gives us average # in tweet per label
	for i in range(8):
		for j in range(9):
			char_dictionary[i][j] /= get_count_for(j, 'train')
	
	word_dict = {}
	for word, array_count in word_dictionary.iteritems():
		if sum(word_dictionary[word]) < count_threshold:
			continue
		word_dict[word] = [count / get_count_for(j, 'train') for count,j in zip(word_dictionary[word], range(9))]
		
					

	return char_dictionary, word_dict

# char_counts, word_counts are dictionaries returned by get_counts method
def get_predictive_value(char_counts, word_counts):
	
	# get the proportions for character-features
	for i in range(8):
		# sum over array
		summ = sum(char_counts[i])
		for j in range(9):
			# divide by (sum - itself)
			char_counts[i][j] /= (summ - char_counts[i][j]+1)

	# get the proportions for word-features
	for word, array_count in word_counts.iteritems():
		summ = sum(array_count)
		for j in range(9):
			array_count[j] /= (summ - array_count[j]+1	)

	return char_counts, word_counts
	

if __name__ == "__main__":

	a,b = get_counts("dataset_oneclass_train")
	c,d = get_predictive_value(a,b)
	D = sorted(list(d.items()))
	f = file("word_counts",'w')
	f.write("\n".join(map(str, D)))
	f.close()
	import numpy


        # compute variances across classes of the predictive value.
	v = []
	for i in sorted(list(c.items())):
		v.append((i[0],numpy.var(i[1])))
	v = sorted(v, lambda a,b:1 if a[1]<b[1] else -1 )

	f = file("variances",'w')
	f.write("\n".join(map(str, v)))
	f.close()
	
