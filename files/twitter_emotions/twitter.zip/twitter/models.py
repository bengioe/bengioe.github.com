#
# models on which the data is tested
#

import sys

import numpy as np


class LinearRegression:
    def __init__(self):
        pass
    
    def fit(self, train):
        X, Y = train
        try:
            # closed form solution
            self.w = np.linalg.inv(X.T.dot(X)).dot(X.T).dot(Y)
        except np.linalg.linalg.LinAlgError:
            # use gradient descent if matrix is singular
            self.fit_grad(train)

    def fit_grad(self, train, lr = 0.0000002, tau = 500):
        X, Y = train
        self.w = np.random.uniform(-1e-3,1e-3,(X.shape[1],Y.shape[1]))
        for i in range(2000):
            grad = -2 * X.T.dot(Y - X.dot(self.w))
            real_lr = (tau * lr / (i+tau))
            self.w = self.w - real_lr * grad

    def test(self, test):
        X, Y = test
        y = X.dot(self.w)
        # return mean square error and classification error rate
        return ((y-Y)**2).sum() / y.shape[0], 1-1.*np.equal(np.argmax(y,axis=1),(np.argmax(Y,axis=1))).sum() / Y.shape[0]


    def eval(self, X):
        return X.dot(self.w)

class NaiveBayes:

    def fit(self, train):
        X, Y = train

        # compute P(Y)
        self.p_y = Y.sum(axis=0) / Y.shape[0]
        self.w = np.zeros((X.shape[1], Y.shape[1]))
        for i in range(X.shape[1]):
            for j in range(Y.shape[1]):
                # number of examples where (X=i,Y=j)
                count = np.logical_and(np.not_equal(X[:,i],0),np.equal(np.argmax(Y,axis=1), j)).sum()
                # number of examples where (Y=j)
                pyx = np.equal(np.argmax(Y,axis=1), j).sum()
                # W_ij = P(X_i!=0|Y=i)
                self.w[i][j] = 1.*count / pyx


    def test(self, test):
        X, Y = test
        errors = 0.0
        # compute P(Y|X) = P(Y=j) \prod P(X_i | Y=j) for each class j
        for k in range(X.shape[0]):
            py = np.array(self.p_y)
            for i in range(X.shape[1]):
                
                if X[k][i] != 0:
                    py *= self.w[i]
                else:
                    py *= 1 - self.w[i]
            y = np.argmax(py)
            if y != np.argmax(Y[k]):
                errors +=1
        return 0, errors / Y.shape[0]

    def eval(self, X):
        # return predictions for X
        predictions = []
        for k in range(X.shape[0]):
            py = np.array(self.p_y)
            for i in range(X.shape[1]):
                
                if X[k][i] != 0:
                    py *= self.w[i]
                else:
                    py *= 1 - self.w[i]
            v = np.zeros(py.shape[0])
            v[np.argmax(py)] = 1
            predictions.append(v)
            
        return np.array(predictions)
        

def twitter():
    import cPickle as pickle
    train = pickle.load(file("train_set",'r'))
    test = pickle.load(file("test_set",'r'))
    return (train, test)

# reduce dataset to only keep examples with given labels
def twitter_redux():
    import cPickle as pickle
    train = pickle.load(file("train_set",'r'))
    test = pickle.load(file("test_set",'r'))
    ntrain = []
    ntest = []

    keep = [0,2,3,6,8]

    a_map = dict(zip(keep,range(len(keep))))
    for i in zip(*train):
        if np.argmax(i[1]) in keep:
            y = np.zeros(len(keep))
            y[a_map[np.argmax(i[1])]] = 1
            ntrain.append((i[0],y))
    for i in zip(*test):
        if np.argmax(i[1]) in keep:
            y = np.zeros(len(keep))
            y[a_map[np.argmax(i[1])]] = 1
            ntest.append((i[0],y))
    ntrain = map(np.array,zip(*ntrain))
    ntest = map(np.array,zip(*ntest))
    print train[0].shape
    print ntrain[0].shape,ntest[0].shape
    return ntrain,ntest


# create random but sortable data
def toy_data():
    X = np.zeros((100,10))
    Y = np.zeros((100,5))
    for i in range(100):
        for j in range(3):
            X[i,np.random.randint(0,10)] = 1
        Y[i,0] = X[i,:5].sum()
        Y[i,3] = X[i,:5].sum()
    return (X[:90],Y[:90]),(X[90:],Y[90:])

# test model on data and show confusion matrix, precision and recall
def test_model(data, model):
    
    train, test = data
    
    model.fit(train)
    
    print "Model scores", model.test(test), "MSE on task"
    ty = model.eval(test[0])
    confusion = np.zeros((test[1].shape[1],test[1].shape[1]))
    print test[0].shape,test[1].shape
    for yp,y in zip(ty,test[1]):
        confusion[np.argmax(yp),np.argmax(y)] += 1
    
    print confusion
    print confusion.sum(axis=0)
    print (1- confusion.diagonal() / confusion.sum(axis=0)) * 100

    precision = confusion.diagonal() / confusion.sum(axis=1)
    recall = confusion.diagonal() / confusion.sum(axis=0)
    print "Precision:", precision, "mean:",precision.mean()
    print "Recall:", recall, "mean:",recall.mean()
    

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print "Defaulting to linear regression"
        data = toy_data()
        model = LinearRegression()
    else:
        try:
            data = eval(sys.argv[1])()
        except Exception, e:
            print "Invalid data",sys.argv[1]
            print e
            exit()
        try:
            args = [eval(i) for i in sys.argv[3:]]
            model = eval(sys.argv[2])(*args)
        except Exception, e:
            print "Invalid model", sys.argv[2]
            print e
            exit()
    test_model(data, model)
