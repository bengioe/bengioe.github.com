# 
# reclassify tweets with conflicting labels (as labeled by participants)
#

import os

def osls(p):
    return [os.path.join(p,i) for i in os.listdir(p)]

data = file('twitter_data','r').read().splitlines()
classified_atoms = [j.split()
                    for i in osls("classifications") 
                    for j in file(i,'r').read().splitlines() ]


tweets = {}

for i in classified_atoms:
    tid = int(i[0])
    clses = list(i[1])
    tweets[tid] = tweets.get(tid, []) + clses
    

OKS = []
NOT_OKS = []

# only ask not reclassify (not_oks) if there is no "most voted" class
for tid,clses in tweets.iteritems():
    T = eval(data[tid])
    if len(set(clses)) > 1:
        # class counts
        cts = sorted([(clses.count(i),i) for i in set(clses)],
                     lambda a,b: 1 if a[0]<b[0] else -1)
        if cts[0][0] > cts[1][0]:
            OKS.append((tid,cts[0][1],T))
        else:
            NOT_OKS.append((tid,clses,T))
    else:
        OKS.append((tid,clses[0],T))

print len(NOT_OKS), "to reclassify"


emots = ["(A)nger/rage",
         "(C)ontempt/disgust",
         "(D)istress/anguish",
         "(E)njoyment/joy",
         "(F)ear/terror",
         "(H)umiliation/shame",
         "(I)nterest/excitement",
         "(S)urprise",
         "(N)eutral"]
emots_letters = [i[1] for i in emots]



f = file("dataset_oneclass",'r').read().splitlines()
seen = {}
for i in f:
    i = i.split(" ",2)
    seen[int(i[0])] = i

f = file("dataset_oneclass",'w')
for i in OKS:
    f.write(str(i[0])+" "+i[1]+" "+repr(i[2])+"\n")

# ask user to reclassify:
for i in NOT_OKS:
    if i[0] in seen:
        i = seen[i[0]]
        print "seen",i
        f.write(str(i[0])+" "+i[1]+" "+i[2]+"\n")
        continue
    print "Tweet:",i[2]
    print "Votes:","".join(sorted(i[1]))
    print "\n".join(emots)
    e =""
    while len(e) != 1 and not e in emots_letters:
        e = raw_input("=>").upper()
    f.write(str(i[0])+" "+e+" "+repr(i[2])+"\n")
    OKS.append((i[0],e,i[2]))


    



