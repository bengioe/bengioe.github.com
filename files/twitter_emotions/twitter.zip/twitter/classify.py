#
# ask user for a label and classify random example in the database, but prioritise
# reclassifing examples that other users have classified.
#
import curses
import random
import time
import getpass
import os

def osls(p):
    return [os.path.join(p,i) for i in os.listdir(p)]

user = getpass.getuser()

# raw data
data = file('twitter_data','r').read().splitlines()

# past classificationss
already_classified = list(set([int(j.split()[0])
                               for i in osls("classifications") if user in i 
                               for j in file(i,'r').read().splitlines() ]))
others_classified = list(set([int(j.split()[0])
                              for i in osls("classifications") if user not in i 
                              for j in file(i,'r').read().splitlines()]))

# examples to reclassfiy
todo = [i for i in others_classified if i not in already_classified]

# output
path = 'classifications/'+user+'_'+str(int(time.time()))
cls = file(path,'w')
os.system("chmod ugo+r "+path)

import locale
locale.setlocale(locale.LC_ALL, '')
code = locale.getpreferredencoding()


def main(scr):
    select_new = True
    emots = ["(A)nger/rage",
             "(C)ontempt/disgust",
             "(D)istress/anguish",
             "(E)njoyment/joy",
             "(F)ear/terror",
             "(H)umiliation/shame",
             "(I)nterest/excitement",
             "(S)urprise",
             "(N)eutral"]
    emots_letters = [i[1] for i in emots]
    visited = already_classified

    # until the user stops, ask for more label
    while 1:
        scr.clear()
        # when user presses next(enter)
        if select_new:
            if len(todo):
                # first select from todo list
                r = todo.pop(0)
            else:
                # otherwise pick random example from data
                r = -1
                while r in visited or r<0:
                    r = random.randint(0,len(data))
            visited.append(r)
            tweet = data[r]
            clses = ['']*len(emots)
            select_new = False

        scr.addstr('Ctrl-C to quit, Enter for next/skip (%d you classified, %d to reclassify)\n\n'%(len(visited), len(todo)))
        scr.addstr(eval(tweet).encode(code))
        rypos = scr.getyx()[0]
        # show toggled choices
        for i,e in enumerate(emots):
            attr = 0
            if clses[i]:
                scr.move(rypos+2+i,30)
                scr.addstr('yes')
                attr = curses.A_REVERSE
            scr.move(rypos+2+i,0)
            scr.addstr(e,attr)

        c = scr.getch()
        if 0 < c < 255:
            c = chr(c)
        else: 
            continue

        if c.upper() in emots_letters:
            c = emots_letters.index(c.upper())
            clses[c] = emots_letters[c] if not clses[c] else ''
        if c == '\n':
            # next
            select_new = True
            if any(map(len,clses)):
                cls.write(str(r)+' '+''.join(clses)+'\n')
                cls.flush()
        scr.refresh()

scr = curses.initscr()
curses.start_color()
curses.noecho()
curses.cbreak()
scr.keypad(1)

try:
    main(scr)
finally:
    curses.nocbreak(); scr.keypad(0); curses.echo()
    curses.endwin()
