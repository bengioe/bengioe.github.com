#
# Show counts of classes in the datasets
#

import os
import random
import sys

# compute the number of examples per emotion per set
def _getcountfor():

    emots = ["Anger/rage",
             "Contempt/disgust",
             "Distress/anguish",
             "Enjoyment/joy",
             "Fear/terror",
             "Humiliation/shame",
             "Interest/excitement",
             "Surprise",
             "Neutral"]

    emot_letters = [i[0] for i in emots]
    convert = lambda x: emot_letters.index(x)

    testdata = [convert(i.split(" ",2)[1])
                for i in file("dataset_oneclass_test",'r').read().splitlines()]

    traindata = [convert(i.split(" ",2)[1])
                 for i in file("dataset_oneclass_train",'r').read().splitlines()]

    testcounts = {}
    traincounts = {}
    for i in testdata:
        testcounts[i] = testcounts.get(i, 0) + 1

    for i in traindata:
        traincounts[i] = traincounts.get(i, 0) + 1

    counts= {"train":traincounts,"test":testcounts}
    def f(L, dataset):
        return counts[dataset][L]
    return f

get_count_for = _getcountfor()

if __name__=="__main__":
    print "test:"
    for i,l in zip(range(9),"ACDEFHISN"):
        print l,get_count_for(i,"test"),get_count_for(i,"test")/150.*100,"\b%"
    print "\ntrain:"
    for i,l in zip(range(9),"ACDEFHISN"):
        print l,get_count_for(i,"train"),get_count_for(i,"train")/850.*100,"\b%"

if 0:
    data = file('twitter_data','r').read().splitlines()
    cls = [[int(j.split()[0]),j.split()[1]]
           for i in os.listdir("classifications")
           for j in file("classifications/"+i,'r').read().splitlines() ]

    emots = ["Anger/rage",
             "Contempt/disgust",
             "Distress/anguish",
             "Enjoyment/joy",
             "Fear/terror",
             "Humiliation/shame",
             "Interest/excitement",
             "Surprise",
             "Neutral"]

    emot_letters = [i[0] for i in emots]
    emot_map = dict([[i, j] for j,i in enumerate(emot_letters)])
    emot_samples = [[] for i in emots]

    for i in cls:
        for e in i[1]:
            emot_samples[emot_map[e]].append(eval(data[i[0]]))

    N = int(sys.argv[1]) if len(sys.argv)>=2 else 5
    for i,j in zip(emots,emot_samples):
        random.shuffle(j)
        print "\n"
        print i,"N =",len(j)
        print '-',"\n- ".join(j[:N])
