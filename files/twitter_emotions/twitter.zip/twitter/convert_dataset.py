#
# convert dataset to CSV format and k folds
#

# -*- encoding: utf-8 -*-
from feature_counter import*
import numpy


#extract features for one line
def extract_feature_vector(line, dictionary):
    
    v = numpy.zeros(8+len(dictionary))
    y = numpy.zeros(9)
    # somehow extract the words and labels
    identity, label, tweet = line.split(' ',2)
    tweet = eval(tweet)
    label = label_to_index(label)
    # get number of !
    v[0] = tweet.count('!')
    # get number of ?
    v[1] = tweet.count('?')
    # get number of single periods
    v[2] = len(re.findall("(([^\.]|^)\.([^\.]|$))", tweet))
    # get number of more than one period together
    v[3] = len(re.findall(u"(([\.]{2,}|…))", tweet))
    # get number of commas
    v[4] = tweet.count(',')
    # get number of caps
    v[5] = sum(1 for letter in tweet if letter.isupper())
    # get number of characters
    v[6] = len(tweet)
    # get number of words
    v[7] = len(tweet.split(' '))
    
    
    tweet = re.sub("((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)", "", tweet)
    # build words and labels
    # split on non alphanum
    for word in re.split('[^a-zA-Z0-9\']+', tweet.lower()):
        #replace >=2 letter repetitions with 2 letters (e.g. foooooo => foo)
        word = re.sub("([a-z])\\1+",
                      lambda x:x.group(0)[:2],
                      word)
        if word in dictionary:
            v[8+dictionary[word]] += 1
    y[label] = 1
    return v, y
            
#extract all features for all examples
def extract_features(feature_path, path, output, k=11, mostn=100):

    a,b = get_counts(feature_path, k)
    c,d = get_predictive_value(a,b)
    D = sorted(map(lambda x:(x[0], numpy.var(x[1])),
                   list(d.items())),
               lambda x,y: 1 if x[1] < y[1] else -1)[:mostn]
    d = dict(D)
    for i,w in enumerate(d):
        d[w] = i
    f = open(path, 'r')
    X = []
    Y = []
    for line in f:
        x,y = extract_feature_vector(line, d)
        X.append(x)
        Y.append(y)


    import cPickle as pickle
    pickle.dump((numpy.array(X),numpy.array(Y)),file(output,'w'),2)

    f = file(output+'.csv','w')
    f.write("exclamation_mark,question_mark,dot,ellipsis,commas,capitals,length,nwords,")
    for w in D:
        f.write('"'+w[0]+'",')
    f.write("class\n")
    for x,y in zip(X,Y):
        for i in x:
            f.write(str(int(i))+",")
        f.write(str(numpy.argmax(y))+"\n")
    
       
#extract features for k-folds, and return all folds
def extract_features_kfold(feature_path, test_path, K, count_threshold,mostn=300):

    import random
    random.seed(1)
    dataset = file(feature_path,'r').read().splitlines()
    testset = file(test_path,'r').read().splitlines()
    random.shuffle(dataset)
    foldsize = len(dataset) / K

    sets = []

    for k in range(K):
        fold = dataset[:k*foldsize]+dataset[(k+1)*foldsize:]
        validation_fold = dataset[k*foldsize:(k+1)*foldsize]
        a,b = get_counts(fold, count_threshold)
        c,d = get_predictive_value(a,b)
        d = dict(sorted(map(lambda x:(x[0], numpy.var(x[1])),
                            list(d.items())),
                        lambda x,y: 1 if x[1] < y[1] else -1)[:mostn])
        
        for i,w in enumerate(d):
            d[w] = i
        trainX = []

        trainY = []
        for line in fold:
            x,y = extract_feature_vector(line, d)
            trainX.append(x)
            trainY.append(y)

        validX = []
        validY = []
        for line in validation_fold:
            x,y = extract_feature_vector(line, d)
            validX.append(x)
            validY.append(y)

        testX = []
        testY = []
        for line in testset:
            x,y = extract_feature_vector(line, d)
            testX.append(x)
            testY.append(y)
        sets.append(map(numpy.array,[trainX,trainY,validX,validY,testX,testY]))

    return sets
    
if __name__ == "__main__":
    extract_features("dataset_oneclass_train","dataset_oneclass_train","train_set")
    extract_features("dataset_oneclass_train","dataset_oneclass_test","test_set")
    
    
