#
# stream tweets from north america and save them in a file 
#

#https://github.com/geduldig/TwitterAPI
#pip install --user TwitterAPI
from TwitterAPI import TwitterAPI


CONSUMER_KEY = 'n4kCz7oTmi24I3afP6VlvrbSG'
CONSUMER_SECRET = 'c5ZL2E3XSC8nm3QhiNdlu8WqHtX6bVjD2tgiVQ3PO560hEpPJ3'
ACCESS_TOKEN_KEY = '502318662-x2L25kSnc073HWYIv8KPOM2flCXo5MpGeqKdh2Xb'
ACCESS_TOKEN_SECRET = '3RhPqJKggh6SdBYRUWSwoV8BanQUFdLH1XkEX2wsasOjN'

api = TwitterAPI(
CONSUMER_KEY,
CONSUMER_SECRET,
ACCESS_TOKEN_KEY,
ACCESS_TOKEN_SECRET)

r = api.request('statuses/filter',{'locations':'-120,35,-70,48'})


data = file("twitter_data_tuesday",'a')

for item in r:
    if 'text' in item:
        data.write(repr(item['text'])+"\n")
        print item['text'],'\n'
    data.flush()
    
